import { createContext, useContext, useState, type ReactNode } from 'react'

export interface PlayerInput {
  name: string
  number: string
  pontos: string
  rebotes: string
  arremessos: string
  roubosDeBola: string
}

export interface PlayerStat {
  player: string
  fullName: string
  number: number
  pontos: number
  rebotes: number
  arremessos: number
  roubosDeBola: number
}

const defaultPlayers: PlayerInput[] = [
  { name: 'Nikola Jokic', number: '15', pontos: '29', rebotes: '14', arremessos: '13', roubosDeBola: '4' },
  { name: 'Shai Gilgeous-Alexander', number: '2', pontos: '32', rebotes: '5', arremessos: '16', roubosDeBola: '3' },
  { name: 'Luka Doncic', number: '77', pontos: '34', rebotes: '9', arremessos: '15', roubosDeBola: '2' },
  { name: 'Giannis Antetokounmpo', number: '34', pontos: '31', rebotes: '12', arremessos: '11', roubosDeBola: '1' },
  { name: 'Jayson Tatum', number: '0', pontos: '27', rebotes: '8', arremessos: '12', roubosDeBola: '2' },
]

interface PlayersContextValue {
  players: PlayerInput[]
  setPlayers: (p: PlayerInput[]) => void
  getStats: () => PlayerStat[]
}

const PlayersContext = createContext<PlayersContextValue | null>(null)

export function PlayersProvider({ children }: { children: ReactNode }) {
  const [players, setPlayers] = useState<PlayerInput[]>(defaultPlayers)

  const getStats = (): PlayerStat[] =>
    players.map((p) => ({
      player: p.name.split(' ')[0],
      fullName: p.name,
      number: Number(p.number),
      pontos: Number(p.pontos),
      rebotes: Number(p.rebotes),
      arremessos: Number(p.arremessos),
      roubosDeBola: Number(p.roubosDeBola),
    }))

  return (
    <PlayersContext.Provider value={{ players, setPlayers, getStats }}>
      {children}
    </PlayersContext.Provider>
  )
}

export function usePlayers() {
  const ctx = useContext(PlayersContext)
  if (!ctx) throw new Error('usePlayers must be used within PlayersProvider')
  return ctx
}
