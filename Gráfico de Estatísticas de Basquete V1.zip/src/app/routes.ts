import { createBrowserRouter } from 'react-router'
import FormPage from '../pages/FormPage'
import StatsPage from '../pages/StatsPage'

export const router = createBrowserRouter([
  { path: '/', Component: FormPage },
  { path: '/stats', Component: StatsPage },
])
