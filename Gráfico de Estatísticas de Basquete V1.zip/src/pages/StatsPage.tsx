import { useState, useMemo } from 'react'
import { useNavigate } from 'react-router'
import {
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend,
  RadarChart, Radar, PolarGrid, PolarAngleAxis, ResponsiveContainer,
  LineChart, Line,
} from 'recharts'
import { usePlayers } from '../context/PlayersContext'

const GREEN = '#22c55e'
const GREEN_LIGHT = '#4ade80'
const GREEN_DIM = '#166534'
const GREEN_MID = '#16a34a'
const SURFACE = '#0f1a0f'
const BORDER = '#1f3322'
const TEXT = '#86efac'
const MUTED = '#4b7a4b'

const LINE_COLORS = [GREEN, '#86efac', '#4ade80', '#166534', '#16a34a', '#bbf7d0', '#052e16', '#dcfce7']

type ChartTab = 'barras' | 'linha' | 'radar'

const CustomTooltip = ({ active, payload, label }: any) => {
  if (!active || !payload?.length) return null
  return (
    <div style={{ background: '#0f1a0f', border: `1px solid ${BORDER}`, borderRadius: 4, padding: '10px 14px', fontFamily: "'Barlow', sans-serif", fontSize: 13 }}>
      <p style={{ color: GREEN_LIGHT, fontWeight: 700, marginBottom: 6, letterSpacing: 1 }}>{label}</p>
      {payload.map((p: any) => (
        <div key={p.name} style={{ display: 'flex', gap: 8, alignItems: 'center', marginBottom: 3 }}>
          <span style={{ width: 8, height: 8, borderRadius: '50%', background: p.color, display: 'inline-block' }} />
          <span style={{ color: TEXT }}>{p.name}:</span>
          <span style={{ color: '#fff', fontFamily: "'JetBrains Mono', monospace", fontWeight: 600 }}>{p.value}</span>
        </div>
      ))}
    </div>
  )
}

export default function StatsPage() {
  const { getStats } = usePlayers()
  const navigate = useNavigate()
  const [tab, setTab] = useState<ChartTab>('barras')
  const [activePlayer, setActivePlayer] = useState<string | null>(null)

  const statsData = useMemo(() => getStats(), [getStats])

  const totalPontos = statsData.reduce((s, p) => s + p.pontos, 0)
  const totalRebotes = statsData.reduce((s, p) => s + p.rebotes, 0)
  const totalArremessos = statsData.reduce((s, p) => s + p.arremessos, 0)
  const totalRoubos = statsData.reduce((s, p) => s + p.roubosDeBola, 0)
  const eficiencia = ((totalPontos / (totalArremessos * 2)) * 100).toFixed(1)

  const statCards = [
    { label: 'Pontos Totais', value: totalPontos, sub: 'Time' },
    { label: 'Rebotes Totais', value: totalRebotes, sub: 'Time' },
    { label: 'Arremessos', value: totalArremessos, sub: `${eficiencia}% eficiência` },
    { label: 'Roubos de Bola', value: totalRoubos, sub: 'Time' },
  ]

  // Quarter data: distribute pontos across 4 quarters per player
  const quarterData = [1, 2, 3, 4].map((q, qi) => {
    const entry: Record<string, any> = { quarter: `${q}T` }
    statsData.forEach(p => {
      const weights = [0.28, 0.30, 0.24, 0.18]
      entry[p.player] = Math.round(p.pontos * weights[qi])
    })
    return entry
  })

  // Radar: normalize stats to 0-100 scale
  const maxPts = Math.max(...statsData.map(p => p.pontos))
  const maxReb = Math.max(...statsData.map(p => p.rebotes))
  const maxArr = Math.max(...statsData.map(p => p.arremessos))
  const maxRou = Math.max(...statsData.map(p => p.roubosDeBola))

  const radarPlayers = statsData.slice(0, 3)
  const radarData = [
    { stat: 'Pontos', ...Object.fromEntries(radarPlayers.map(p => [p.player, Math.round((p.pontos / maxPts) * 100)])) },
    { stat: 'Rebotes', ...Object.fromEntries(radarPlayers.map(p => [p.player, Math.round((p.rebotes / maxReb) * 100)])) },
    { stat: 'Arremessos', ...Object.fromEntries(radarPlayers.map(p => [p.player, Math.round((p.arremessos / maxArr) * 100)])) },
    { stat: 'Roubos', ...Object.fromEntries(radarPlayers.map(p => [p.player, Math.round((p.roubosDeBola / maxRou) * 100)])) },
    { stat: 'Eficiência', ...Object.fromEntries(radarPlayers.map(p => [p.player, Math.round((p.pontos / (p.arremessos * 2)) * 100)])) },
  ]

  return (
    <div style={{ background: '#080c08', minHeight: '100vh', fontFamily: "'Barlow', sans-serif", color: '#e8f5e8' }}>
      {/* Header */}
      <header style={{ borderBottom: `1px solid ${BORDER}`, padding: '20px 32px', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 14 }}>
          <div style={{ width: 40, height: 40, borderRadius: '50%', background: GREEN, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
            <svg width="22" height="22" viewBox="0 0 24 24" fill="none">
              <circle cx="12" cy="12" r="10" stroke="#080c08" strokeWidth="2"/>
              <path d="M12 2 Q8 7 8 12 Q8 17 12 22" stroke="#080c08" strokeWidth="1.5" fill="none"/>
              <path d="M12 2 Q16 7 16 12 Q16 17 12 22" stroke="#080c08" strokeWidth="1.5" fill="none"/>
              <path d="M2 12 Q7 9 12 9 Q17 9 22 12" stroke="#080c08" strokeWidth="1.5" fill="none"/>
              <path d="M2 12 Q7 15 12 15 Q17 15 22 12" stroke="#080c08" strokeWidth="1.5" fill="none"/>
            </svg>
          </div>
          <div>
            <h1 style={{ fontFamily: "'Barlow Condensed', sans-serif", fontSize: 22, fontWeight: 800, letterSpacing: 2, textTransform: 'uppercase', color: '#fff', margin: 0, lineHeight: 1 }}>BasketStats</h1>
            <p style={{ fontSize: 11, color: MUTED, margin: 0, fontFamily: "'JetBrains Mono', monospace", letterSpacing: 1 }}>TEMPORADA 2025 · PLAYOFFS</p>
          </div>
        </div>
        <div style={{ display: 'flex', alignItems: 'center', gap: 16 }}>
          <button
            onClick={() => navigate('/')}
            style={{
              display: 'flex', alignItems: 'center', gap: 6,
              padding: '7px 16px', border: `1px solid ${BORDER}`, borderRadius: 4,
              background: 'transparent', color: MUTED, cursor: 'pointer',
              fontFamily: "'Barlow Condensed', sans-serif", fontSize: 12, fontWeight: 700,
              letterSpacing: 1, textTransform: 'uppercase', transition: 'all 0.15s',
            }}
          >
            <svg width="12" height="12" viewBox="0 0 12 12" fill="none">
              <path d="M8 2L4 6l4 4" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
            </svg>
            Editar Dados
          </button>
          <div style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
            <span style={{ width: 8, height: 8, borderRadius: '50%', background: GREEN, boxShadow: `0 0 6px ${GREEN}` }} />
            <span style={{ fontSize: 12, color: TEXT, fontFamily: "'JetBrains Mono', monospace" }}>AO VIVO</span>
          </div>
        </div>
      </header>

      <main style={{ maxWidth: 1200, margin: '0 auto', padding: '32px 24px' }}>
        {/* Match Banner */}
        <div style={{ background: SURFACE, border: `1px solid ${BORDER}`, borderRadius: 6, padding: '20px 28px', marginBottom: 32, display: 'flex', alignItems: 'center', justifyContent: 'space-between', position: 'relative', overflow: 'hidden' }}>
          <div style={{ position: 'absolute', top: 0, left: 0, right: 0, height: 2, background: `linear-gradient(90deg, transparent, ${GREEN}, transparent)` }} />
          <div style={{ textAlign: 'center' }}>
            <div style={{ fontFamily: "'Barlow Condensed', sans-serif", fontSize: 13, fontWeight: 600, color: MUTED, letterSpacing: 2, textTransform: 'uppercase' }}>Time A</div>
            <div style={{ fontFamily: "'Barlow Condensed', sans-serif", fontSize: 48, fontWeight: 800, color: GREEN, lineHeight: 1 }}>{totalPontos}</div>
            <div style={{ fontSize: 11, color: MUTED, fontFamily: "'JetBrains Mono', monospace" }}>PONTOS</div>
          </div>
          <div style={{ textAlign: 'center' }}>
            <div style={{ fontFamily: "'Barlow Condensed', sans-serif", fontSize: 12, color: MUTED, letterSpacing: 3, textTransform: 'uppercase', marginBottom: 4 }}>4º QUARTO · FINAL</div>
            <div style={{ fontFamily: "'Barlow Condensed', sans-serif", fontSize: 28, fontWeight: 700, color: '#fff' }}>VS</div>
            <div style={{ fontSize: 11, color: MUTED, fontFamily: "'JetBrains Mono', monospace" }}>NBA · JUN 2025</div>
          </div>
          <div style={{ textAlign: 'center' }}>
            <div style={{ fontFamily: "'Barlow Condensed', sans-serif", fontSize: 13, fontWeight: 600, color: MUTED, letterSpacing: 2, textTransform: 'uppercase' }}>Time B</div>
            <div style={{ fontFamily: "'Barlow Condensed', sans-serif", fontSize: 48, fontWeight: 800, color: '#fff', lineHeight: 1 }}>128</div>
            <div style={{ fontSize: 11, color: MUTED, fontFamily: "'JetBrains Mono', monospace" }}>PONTOS</div>
          </div>
        </div>

        {/* Stat Cards */}
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 16, marginBottom: 32 }}>
          {statCards.map((card) => (
            <div key={card.label} style={{ background: SURFACE, border: `1px solid ${BORDER}`, borderRadius: 6, padding: '18px 20px', position: 'relative', overflow: 'hidden' }}>
              <div style={{ position: 'absolute', bottom: 0, left: 0, width: '40%', height: 2, background: GREEN, opacity: 0.5 }} />
              <div style={{ fontFamily: "'JetBrains Mono', monospace", fontSize: 36, fontWeight: 600, color: GREEN_LIGHT, lineHeight: 1, marginBottom: 6 }}>{card.value}</div>
              <div style={{ fontSize: 12, fontWeight: 600, color: '#e8f5e8', textTransform: 'uppercase', letterSpacing: 1, marginBottom: 2 }}>{card.label}</div>
              <div style={{ fontSize: 11, color: MUTED }}>{card.sub}</div>
            </div>
          ))}
        </div>

        {/* Chart */}
        <div style={{ background: SURFACE, border: `1px solid ${BORDER}`, borderRadius: 6, padding: '20px 24px', marginBottom: 24 }}>
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 20 }}>
            <h2 style={{ fontFamily: "'Barlow Condensed', sans-serif", fontSize: 16, fontWeight: 700, textTransform: 'uppercase', letterSpacing: 2, color: '#fff', margin: 0 }}>Estatísticas por Jogador</h2>
            <div style={{ display: 'flex', gap: 4 }}>
              {(['barras', 'linha', 'radar'] as ChartTab[]).map((t) => (
                <button key={t} onClick={() => setTab(t)} style={{ padding: '5px 14px', borderRadius: 3, border: `1px solid ${tab === t ? GREEN : BORDER}`, background: tab === t ? GREEN : 'transparent', color: tab === t ? '#080c08' : MUTED, fontFamily: "'Barlow Condensed', sans-serif", fontSize: 12, fontWeight: 700, letterSpacing: 1, textTransform: 'uppercase', cursor: 'pointer', transition: 'all 0.15s' }}>
                  {t === 'barras' ? 'Barras' : t === 'linha' ? 'Linha' : 'Radar'}
                </button>
              ))}
            </div>
          </div>

          {tab === 'barras' && (
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={statsData} barGap={2} barCategoryGap="25%">
                <CartesianGrid strokeDasharray="3 3" stroke={BORDER} vertical={false} />
                <XAxis dataKey="player" tick={{ fill: MUTED, fontSize: 12, fontFamily: "'Barlow Condensed', sans-serif", letterSpacing: 1 }} axisLine={{ stroke: BORDER }} tickLine={false} />
                <YAxis tick={{ fill: MUTED, fontSize: 11, fontFamily: "'JetBrains Mono', monospace" }} axisLine={false} tickLine={false} />
                <Tooltip content={<CustomTooltip />} cursor={{ fill: 'rgba(34,197,94,0.06)' }} />
                <Legend wrapperStyle={{ fontFamily: "'Barlow Condensed', sans-serif", fontSize: 12, letterSpacing: 1, textTransform: 'uppercase', color: MUTED }} />
                <Bar dataKey="pontos" name="Pontos" fill={GREEN} radius={[3, 3, 0, 0]} />
                <Bar dataKey="rebotes" name="Rebotes" fill={GREEN_DIM} radius={[3, 3, 0, 0]} />
                <Bar dataKey="arremessos" name="Arremessos" fill={GREEN_MID} radius={[3, 3, 0, 0]} />
                <Bar dataKey="roubosDeBola" name="Roubos" fill="#14532d" radius={[3, 3, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          )}

          {tab === 'linha' && (
            <ResponsiveContainer width="100%" height={300}>
              <LineChart data={quarterData}>
                <CartesianGrid strokeDasharray="3 3" stroke={BORDER} vertical={false} />
                <XAxis dataKey="quarter" tick={{ fill: MUTED, fontSize: 12, fontFamily: "'Barlow Condensed', sans-serif" }} axisLine={{ stroke: BORDER }} tickLine={false} />
                <YAxis tick={{ fill: MUTED, fontSize: 11, fontFamily: "'JetBrains Mono', monospace" }} axisLine={false} tickLine={false} />
                <Tooltip content={<CustomTooltip />} />
                <Legend wrapperStyle={{ fontFamily: "'Barlow Condensed', sans-serif", fontSize: 12, letterSpacing: 1, textTransform: 'uppercase', color: MUTED }} />
                {statsData.map((p, i) => (
                  <Line key={p.player} type="monotone" dataKey={p.player} stroke={LINE_COLORS[i % LINE_COLORS.length]} strokeWidth={2} dot={{ fill: LINE_COLORS[i % LINE_COLORS.length], r: 4, strokeWidth: 0 }} activeDot={{ r: 6 }} />
                ))}
              </LineChart>
            </ResponsiveContainer>
          )}

          {tab === 'radar' && (
            <ResponsiveContainer width="100%" height={300}>
              <RadarChart data={radarData}>
                <PolarGrid stroke={BORDER} />
                <PolarAngleAxis dataKey="stat" tick={{ fill: MUTED, fontSize: 12, fontFamily: "'Barlow Condensed', sans-serif", letterSpacing: 1 }} />
                {radarPlayers.map((p, i) => (
                  <Radar key={p.player} name={p.player} dataKey={p.player} stroke={LINE_COLORS[i]} fill={LINE_COLORS[i]} fillOpacity={0.12 - i * 0.03} strokeWidth={2} />
                ))}
                <Legend wrapperStyle={{ fontFamily: "'Barlow Condensed', sans-serif", fontSize: 12, letterSpacing: 1, textTransform: 'uppercase', color: MUTED }} />
                <Tooltip content={<CustomTooltip />} />
              </RadarChart>
            </ResponsiveContainer>
          )}
        </div>

        {/* Player Table */}
        <div style={{ background: SURFACE, border: `1px solid ${BORDER}`, borderRadius: 6, overflow: 'hidden' }}>
          <div style={{ padding: '16px 24px', borderBottom: `1px solid ${BORDER}` }}>
            <h2 style={{ fontFamily: "'Barlow Condensed', sans-serif", fontSize: 16, fontWeight: 700, textTransform: 'uppercase', letterSpacing: 2, color: '#fff', margin: 0 }}>Tabela de Desempenho</h2>
          </div>
          <table style={{ width: '100%', borderCollapse: 'collapse' }}>
            <thead>
              <tr style={{ borderBottom: `1px solid ${BORDER}` }}>
                {['#', 'Jogador', 'Pontos', 'Rebotes', 'Arremessos', 'Roubos', 'Efic.'].map((h) => (
                  <th key={h} style={{ padding: '10px 20px', textAlign: h === '#' || h === 'Jogador' ? 'left' : 'center', fontFamily: "'Barlow Condensed', sans-serif", fontSize: 11, fontWeight: 700, letterSpacing: 2, color: MUTED, textTransform: 'uppercase' }}>{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {statsData.map((row) => {
                const eff = ((row.pontos / (row.arremessos * 2)) * 100).toFixed(0)
                const isActive = activePlayer === row.player
                return (
                  <tr key={row.player} onMouseEnter={() => setActivePlayer(row.player)} onMouseLeave={() => setActivePlayer(null)} style={{ borderBottom: `1px solid ${BORDER}`, background: isActive ? 'rgba(34,197,94,0.05)' : 'transparent', transition: 'background 0.15s', cursor: 'default' }}>
                    <td style={{ padding: '12px 20px', fontFamily: "'JetBrains Mono', monospace", fontSize: 13, color: MUTED }}>{row.number}</td>
                    <td style={{ padding: '12px 20px', fontWeight: 600, color: isActive ? GREEN_LIGHT : '#e8f5e8', fontSize: 14 }}>{row.fullName}</td>
                    <td style={{ padding: '12px 20px', textAlign: 'center', fontFamily: "'JetBrains Mono', monospace", fontSize: 14, fontWeight: 600, color: GREEN }}>{row.pontos}</td>
                    <td style={{ padding: '12px 20px', textAlign: 'center', fontFamily: "'JetBrains Mono', monospace", fontSize: 14, color: TEXT }}>{row.rebotes}</td>
                    <td style={{ padding: '12px 20px', textAlign: 'center', fontFamily: "'JetBrains Mono', monospace", fontSize: 14, color: TEXT }}>{row.arremessos}</td>
                    <td style={{ padding: '12px 20px', textAlign: 'center', fontFamily: "'JetBrains Mono', monospace", fontSize: 14, color: TEXT }}>{row.roubosDeBola}</td>
                    <td style={{ padding: '12px 20px', textAlign: 'center' }}>
                      <div style={{ display: 'inline-flex', alignItems: 'center', gap: 6 }}>
                        <div style={{ width: 48, height: 4, background: '#1a2b1a', borderRadius: 2, overflow: 'hidden' }}>
                          <div style={{ width: `${Math.min(Number(eff), 100)}%`, height: '100%', background: Number(eff) > 75 ? GREEN : Number(eff) > 60 ? GREEN_MID : GREEN_DIM, borderRadius: 2 }} />
                        </div>
                        <span style={{ fontFamily: "'JetBrains Mono', monospace", fontSize: 12, color: MUTED }}>{eff}%</span>
                      </div>
                    </td>
                  </tr>
                )
              })}
            </tbody>
          </table>
        </div>

        <p style={{ textAlign: 'center', fontSize: 11, color: MUTED, fontFamily: "'JetBrains Mono', monospace", marginTop: 32, letterSpacing: 1 }}>
          BASKESTSTATS · NBA 2K25 · RATINGS OFICIAIS
        </p>
      </main>
    </div>
  )
}
