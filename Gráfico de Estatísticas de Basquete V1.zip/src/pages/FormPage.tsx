import { useState } from 'react'
import { useNavigate } from 'react-router'
import { usePlayers, type PlayerInput } from '../context/PlayersContext'

const GREEN = '#22c55e'
const GREEN_LIGHT = '#4ade80'
const SURFACE = '#0f1a0f'
const BORDER = '#1f3322'
const MUTED = '#4b7a4b'
const TEXT = '#86efac'

const FIELDS: { key: keyof PlayerInput; label: string; placeholder: string }[] = [
  { key: 'name', label: 'Nome', placeholder: 'Ex: LeBron James' },
  { key: 'number', label: 'Número', placeholder: '23' },
  { key: 'pontos', label: 'Pontos', placeholder: '28' },
  { key: 'rebotes', label: 'Rebotes', placeholder: '9' },
  { key: 'arremessos', label: 'Arremessos', placeholder: '12' },
  { key: 'roubosDeBola', label: 'Roubos de Bola', placeholder: '3' },
]

const emptyPlayer = (): PlayerInput => ({
  name: '', number: '', pontos: '', rebotes: '', arremessos: '', roubosDeBola: '',
})

export default function FormPage() {
  const { players, setPlayers } = usePlayers()
  const navigate = useNavigate()
  const [rows, setRows] = useState<PlayerInput[]>(players.map(p => ({ ...p })))
  const [errors, setErrors] = useState<number[]>([])
  const [submitted, setSubmitted] = useState(false)

  const update = (i: number, key: keyof PlayerInput, val: string) => {
    setRows(prev => prev.map((r, idx) => idx === i ? { ...r, [key]: val } : r))
    setErrors(prev => prev.filter(e => e !== i))
  }

  const addPlayer = () => {
    if (rows.length >= 8) return
    setRows(prev => [...prev, emptyPlayer()])
  }

  const removePlayer = (i: number) => {
    if (rows.length <= 2) return
    setRows(prev => prev.filter((_, idx) => idx !== i))
    setErrors(prev => prev.filter(e => e !== i).map(e => e > i ? e - 1 : e))
  }

  const validate = () => {
    const bad: number[] = []
    rows.forEach((r, i) => {
      const numericKeys: (keyof PlayerInput)[] = ['number', 'pontos', 'rebotes', 'arremessos', 'roubosDeBola']
      const hasEmpty = !r.name.trim() || numericKeys.some(k => r[k] === '' || isNaN(Number(r[k])))
      if (hasEmpty) bad.push(i)
    })
    return bad
  }

  const handleSubmit = () => {
    const bad = validate()
    if (bad.length) { setErrors(bad); return }
    setPlayers(rows)
    setSubmitted(true)
    setTimeout(() => navigate('/stats'), 600)
  }

  const handleReset = () => {
    setRows([
      { name: 'Nikola Jokic', number: '15', pontos: '29', rebotes: '14', arremessos: '13', roubosDeBola: '4' },
      { name: 'Shai Gilgeous-Alexander', number: '2', pontos: '32', rebotes: '5', arremessos: '16', roubosDeBola: '3' },
      { name: 'Luka Doncic', number: '77', pontos: '34', rebotes: '9', arremessos: '15', roubosDeBola: '2' },
      { name: 'Giannis Antetokounmpo', number: '34', pontos: '31', rebotes: '12', arremessos: '11', roubosDeBola: '1' },
      { name: 'Jayson Tatum', number: '0', pontos: '27', rebotes: '8', arremessos: '12', roubosDeBola: '2' },
    ])
    setErrors([])
  }

  return (
    <div style={{ background: '#080c08', minHeight: '100vh', fontFamily: "'Barlow', sans-serif", color: '#e8f5e8' }}>
      {/* Header */}
      <header style={{ borderBottom: `1px solid ${BORDER}`, padding: '20px 32px', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 14 }}>
          <div style={{ width: 40, height: 40, borderRadius: '50%', background: GREEN, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
            <svg width="22" height="22" viewBox="0 0 24 24" fill="none">
              <circle cx="12" cy="12" r="10" stroke="#080c08" strokeWidth="2"/>
              <path d="M12 2 Q8 7 8 12 Q8 17 12 22" stroke="#080c08" strokeWidth="1.5" fill="none"/>
              <path d="M12 2 Q16 7 16 12 Q16 17 12 22" stroke="#080c08" strokeWidth="1.5" fill="none"/>
              <path d="M2 12 Q7 9 12 9 Q17 9 22 12" stroke="#080c08" strokeWidth="1.5" fill="none"/>
              <path d="M2 12 Q7 15 12 15 Q17 15 22 12" stroke="#080c08" strokeWidth="1.5" fill="none"/>
            </svg>
          </div>
          <div>
            <h1 style={{ fontFamily: "'Barlow Condensed', sans-serif", fontSize: 22, fontWeight: 800, letterSpacing: 2, textTransform: 'uppercase', color: '#fff', margin: 0, lineHeight: 1 }}>
              BasketStats
            </h1>
            <p style={{ fontSize: 11, color: MUTED, margin: 0, fontFamily: "'JetBrains Mono', monospace", letterSpacing: 1 }}>
              INSERIR DADOS · NBA 2K25
            </p>
          </div>
        </div>

        {/* Step indicator */}
        <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
            <div style={{ width: 28, height: 28, borderRadius: '50%', background: GREEN, display: 'flex', alignItems: 'center', justifyContent: 'center', fontFamily: "'Barlow Condensed', sans-serif", fontWeight: 800, fontSize: 13, color: '#080c08' }}>1</div>
            <span style={{ fontFamily: "'Barlow Condensed', sans-serif", fontSize: 12, fontWeight: 700, letterSpacing: 1, color: GREEN, textTransform: 'uppercase' }}>Dados</span>
          </div>
          <div style={{ width: 32, height: 1, background: BORDER }} />
          <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
            <div style={{ width: 28, height: 28, borderRadius: '50%', border: `1px solid ${BORDER}`, display: 'flex', alignItems: 'center', justifyContent: 'center', fontFamily: "'Barlow Condensed', sans-serif", fontWeight: 800, fontSize: 13, color: MUTED }}>2</div>
            <span style={{ fontFamily: "'Barlow Condensed', sans-serif", fontSize: 12, fontWeight: 700, letterSpacing: 1, color: MUTED, textTransform: 'uppercase' }}>Dashboard</span>
          </div>
        </div>
      </header>

      <main style={{ maxWidth: 960, margin: '0 auto', padding: '40px 24px' }}>
        {/* Title */}
        <div style={{ marginBottom: 32 }}>
          <h2 style={{ fontFamily: "'Barlow Condensed', sans-serif", fontSize: 32, fontWeight: 800, textTransform: 'uppercase', letterSpacing: 3, color: '#fff', margin: 0, lineHeight: 1 }}>
            Configure os Jogadores
          </h2>
          <p style={{ fontSize: 14, color: MUTED, marginTop: 8, margin: '8px 0 0' }}>
            Insira as estatísticas de cada jogador. Os dados serão exibidos no dashboard.
          </p>
        </div>

        {/* Column headers */}
        <div style={{ display: 'grid', gridTemplateColumns: '2fr 80px 90px 90px 100px 110px 40px', gap: 10, padding: '0 16px', marginBottom: 8 }}>
          {FIELDS.map(f => (
            <div key={f.key} style={{ fontFamily: "'Barlow Condensed', sans-serif", fontSize: 11, fontWeight: 700, letterSpacing: 2, color: MUTED, textTransform: 'uppercase' }}>
              {f.label}
            </div>
          ))}
          <div />
        </div>

        {/* Player rows */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: 10, marginBottom: 20 }}>
          {rows.map((row, i) => {
            const hasError = errors.includes(i)
            return (
              <div
                key={i}
                style={{
                  display: 'grid',
                  gridTemplateColumns: '2fr 80px 90px 90px 100px 110px 40px',
                  gap: 10,
                  background: SURFACE,
                  border: `1px solid ${hasError ? '#ef4444' : BORDER}`,
                  borderRadius: 6,
                  padding: '12px 16px',
                  alignItems: 'center',
                  position: 'relative',
                  transition: 'border-color 0.15s',
                  boxShadow: hasError ? '0 0 0 1px rgba(239,68,68,0.2)' : 'none',
                }}
              >
                {/* Player number badge */}
                <div style={{ position: 'relative' }}>
                  <div style={{ position: 'absolute', left: -8, top: '50%', transform: 'translateY(-50%)', width: 18, height: 18, borderRadius: '50%', background: hasError ? '#ef4444' : '#14261a', border: `1px solid ${hasError ? '#ef4444' : BORDER}`, display: 'flex', alignItems: 'center', justifyContent: 'center', fontFamily: "'JetBrains Mono', monospace", fontSize: 9, color: hasError ? '#fff' : MUTED }}>
                    {i + 1}
                  </div>
                  <input
                    value={row.name}
                    onChange={e => update(i, 'name', e.target.value)}
                    placeholder="Nome do jogador"
                    style={inputStyle(hasError)}
                  />
                </div>
                {(['number', 'pontos', 'rebotes', 'arremessos', 'roubosDeBola'] as (keyof PlayerInput)[]).map(key => (
                  <input
                    key={key}
                    type="number"
                    value={row[key]}
                    onChange={e => update(i, key, e.target.value)}
                    placeholder="0"
                    min="0"
                    style={{ ...inputStyle(hasError), textAlign: 'center' }}
                  />
                ))}
                <button
                  onClick={() => removePlayer(i)}
                  disabled={rows.length <= 2}
                  style={{
                    width: 32, height: 32, borderRadius: 4,
                    border: `1px solid ${rows.length <= 2 ? '#111' : BORDER}`,
                    background: 'transparent',
                    color: rows.length <= 2 ? '#1f2f1f' : '#6b9b6b',
                    cursor: rows.length <= 2 ? 'not-allowed' : 'pointer',
                    display: 'flex', alignItems: 'center', justifyContent: 'center',
                    transition: 'all 0.15s',
                    fontSize: 16,
                  }}
                  title="Remover jogador"
                >
                  ×
                </button>
              </div>
            )
          })}
        </div>

        {errors.length > 0 && (
          <p style={{ fontSize: 12, color: '#ef4444', fontFamily: "'JetBrains Mono', monospace", marginBottom: 16, letterSpacing: 0.5 }}>
            Preencha todos os campos corretamente nos jogadores destacados.
          </p>
        )}

        {/* Add player */}
        <button
          onClick={addPlayer}
          disabled={rows.length >= 8}
          style={{
            display: 'flex', alignItems: 'center', gap: 8,
            padding: '10px 20px',
            border: `1px dashed ${rows.length >= 8 ? '#1a2b1a' : BORDER}`,
            borderRadius: 6,
            background: 'transparent',
            color: rows.length >= 8 ? '#1a2b1a' : MUTED,
            cursor: rows.length >= 8 ? 'not-allowed' : 'pointer',
            fontFamily: "'Barlow Condensed', sans-serif",
            fontSize: 13, fontWeight: 700, letterSpacing: 1, textTransform: 'uppercase',
            marginBottom: 40,
            transition: 'all 0.15s',
            width: '100%',
            justifyContent: 'center',
          }}
        >
          <span style={{ fontSize: 18, lineHeight: 1 }}>+</span>
          Adicionar Jogador {rows.length >= 8 ? '(máx. 8)' : `(${rows.length}/8)`}
        </button>

        {/* Actions */}
        <div style={{ display: 'flex', gap: 12, justifyContent: 'flex-end', borderTop: `1px solid ${BORDER}`, paddingTop: 24 }}>
          <button
            onClick={handleReset}
            style={{
              padding: '11px 24px',
              border: `1px solid ${BORDER}`,
              borderRadius: 4,
              background: 'transparent',
              color: MUTED,
              fontFamily: "'Barlow Condensed', sans-serif",
              fontSize: 13, fontWeight: 700, letterSpacing: 2, textTransform: 'uppercase',
              cursor: 'pointer',
              transition: 'all 0.15s',
            }}
          >
            Restaurar Padrão
          </button>
          <button
            onClick={handleSubmit}
            style={{
              padding: '11px 32px',
              border: 'none',
              borderRadius: 4,
              background: submitted ? GREEN_LIGHT : GREEN,
              color: '#080c08',
              fontFamily: "'Barlow Condensed', sans-serif",
              fontSize: 14, fontWeight: 800, letterSpacing: 2, textTransform: 'uppercase',
              cursor: 'pointer',
              transition: 'all 0.2s',
              display: 'flex', alignItems: 'center', gap: 8,
              boxShadow: `0 0 20px rgba(34,197,94,0.3)`,
            }}
          >
            {submitted ? (
              <>
                <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
                  <path d="M3 8l3.5 3.5L13 5" stroke="#080c08" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                </svg>
                Carregando...
              </>
            ) : (
              <>
                Ver Dashboard
                <svg width="14" height="14" viewBox="0 0 14 14" fill="none">
                  <path d="M2 7h10M8 3l4 4-4 4" stroke="#080c08" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                </svg>
              </>
            )}
          </button>
        </div>

        <p style={{ textAlign: 'center', fontSize: 11, color: '#1a2b1a', fontFamily: "'JetBrains Mono', monospace", marginTop: 32, letterSpacing: 1 }}>
          BASKESTSTATS · NBA 2K25 · RATINGS OFICIAIS
        </p>
      </main>
    </div>
  )
}

function inputStyle(hasError: boolean): React.CSSProperties {
  return {
    width: '100%',
    background: 'transparent',
    border: `1px solid ${hasError ? 'rgba(239,68,68,0.4)' : '#1a2b1a'}`,
    borderRadius: 4,
    padding: '7px 10px',
    color: '#e8f5e8',
    fontFamily: "'Barlow', sans-serif",
    fontSize: 13,
    outline: 'none',
    boxSizing: 'border-box',
    transition: 'border-color 0.15s',
  }
}
